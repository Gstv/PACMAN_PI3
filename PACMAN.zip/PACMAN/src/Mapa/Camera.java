package Mapa;

/**
 *
 * @author Gustavo
 */
public class Camera {
    
    public static int x = 0;
    public static int y = 0;
    
}
