package Objetos;

import Pacman.Jogo;
import java.awt.image.BufferedImage;
import java.util.Random;

/**
 *
 * @author Guilherme Delmondes
 */
public class Fruta extends Objetos {
    
    public Fruta(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);
    }
    
}
