package Objetos;

import java.awt.image.BufferedImage;

/**
 *
 * @author Guilherme Delmondes
 */
public class Pontos extends Objetos {

    public Pontos(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);
    }
}
