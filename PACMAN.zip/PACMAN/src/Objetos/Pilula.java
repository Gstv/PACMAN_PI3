package Objetos;

import java.awt.image.BufferedImage;

/**
 *
 * @author Guilherme Delmondes
 */
public class Pilula extends Objetos {

    public Pilula(int x, int y, int width, int height, BufferedImage sprite) {
        super(x, y, width, height, sprite);
    }
}
